﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Math;

namespace People
{
    class Program
    {
        static void Main(string[] args)
        {
            // Person.nextId = 1000;

            Person me = new Person("Dean", 45, "London");

            Person you = new Person("Mary", 25)
            {
                City = "Manchester"
            };
            //you.City = "Manchester";

            you.HaveBirthday();
            me.DisplayDetails();
            you.DisplayDetails();
            // Console.WriteLine(me.age);
            // Console.WriteLine(me.GetAge());
            Console.WriteLine(me.Age);
        }
    }
}
