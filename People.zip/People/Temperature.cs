﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace People
{
    class Temperature
    {
        public double DegreesC { get; set; }

        public double DegreesF
        {
            get
            {
                return DegreesC * 1.8 + 32;
            }
            set
            {
                DegreesC = (value - 32) / 1.8;
            }
        }
    }
}
