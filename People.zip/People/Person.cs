﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace People
{
    class Person
    {
        private static int nextId = 0;

        public int Id { get; private set; }

        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }



        private int age;
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
                if (age > 140)
                {
                    age = 140;
                }
            }
        }


        // Auto-property - no code in get/set, just a ;
        //   You get:
        //     A field, hidden so that you can't ever access it
        //     A get/set, which get the data from that field and set it
        public string City { get; set; }


        public Person(string name, int age, string location)
            :this(name, age)
        {
            City = location;
        }
        public Person(string name, int age)
        {
            GetId();
            Name = name;
            Age = age;
        }


        public void DisplayDetails()
        {
            Console.WriteLine($"({this.Id}) I am {this.Name} from {this.City}, and I am {Age} years old");
        }

        public void HaveBirthday()
        {
            Age++;
        }

        private void GetId()
        {
            Id = nextId++;
        }
    }
}
