﻿using System;

namespace RefDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;  // = 37;
            ChangeIt(out age);
            Console.WriteLine(age);
        }

        private static void ChangeIt(out int x)
        {
            Console.WriteLine("Inside changeit, x is " + x);
            x = 45;
        }

        private static void Swap(ref int x, ref int y)
        {
            int tmp = x;
            x = y; 
            y = tmp;
        }


        //static void Main(string[] args)
        //{
        //    Person me = new Person { Name = "Dean", Age = 37 };
        //    ChangeIt(me);

        //    //Person you = me;
        //    //you.Age = 45;

        //    int age = me?.Age ?? 0;

        //    Console.WriteLine(age);
        //}


        //private static void ChangeIt(Person x)
        //{
        //    x.Age = 45;
        //}
    }
}
