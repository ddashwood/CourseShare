﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefDemo
{
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
