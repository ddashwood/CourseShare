﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StaticDemo
{
    // Static class only contains static members
    static class OfficeUtilities
    {
        public static void Open()
        {
            Console.WriteLine("Opening the office");
        }
        public static void Close()
        {
            Console.WriteLine("Closing the office");
        }
    }
}
