﻿using System;
using StaticDemo.Extensions;
using static System.Console;
using static System.Math;
using static StaticDemo.Gender;

namespace StaticDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            double d = Sqrt(2);


            int x = 5;
            int y = x.Double();
           
            WriteLine(y);


            Employee me = new Employee("Dean", 250000);
            Employee boss = new Employee("Ed", 500000);
            Employee pleb = new Employee("John", 25000) { Gender = Male };

            Console.WriteLine(Employee.nextId);

            
            Demo();

            OfficeUtilities.Open();


        }

        static void Demo()
        {
            WriteLine("Demo");
            WriteLine("Blah");
        }
    }
}
