﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StaticDemo.Extensions
{
    static class IntExtensions
    {
        public static int Double(this int x)
        {
            return x * 2;
        }
    }
}
