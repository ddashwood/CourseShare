﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StaticDemo
{
    class Employee
    {
        // Static - it belongs to the Class, not to the Objects
        public static int nextId = 1;

        public string Name { get; set; }
        public decimal Salary { get; set; }
        public int EmployeeId { get; set; }


        public Gender Gender { get; set; }


        public Employee(string name, decimal salary)
        {
            Name = name;
            Salary = salary;
            EmployeeId = nextId++;
        }

        public static void Demo()
        {
            Console.WriteLine(nextId);
            Console.WriteLine(Name);
        }
    }
}
