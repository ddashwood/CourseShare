﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StaticDemo
{
    enum Gender
    {
        Male = 22,
        Female = 52,
        Alien = 99
    }
}
