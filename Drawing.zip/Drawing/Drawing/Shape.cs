﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Drawing
{
    abstract class Shape
    {
        public abstract double Area { get; }
    }
}
