﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Drawing
{
    class Square : Shape
    {
        public double Length { get; }

        public Square(double length)
        {
            Length = length;
        }

        public override double Area => Length * Length;
    }
}
