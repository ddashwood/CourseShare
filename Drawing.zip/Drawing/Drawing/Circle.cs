﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Drawing
{
    class Circle : Shape
    {
        public double Radius { get; }

        public Circle(double radius)
        {
            Radius = radius;
        }

        public override double Area => Math.PI * Math.Pow(Radius, 2);
    }
}
